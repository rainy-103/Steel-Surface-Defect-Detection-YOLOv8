# Extended NEU-DET annotation artifact

This archive supports the fixed three-class split used in the manuscript.
It contains YOLO-format object labels for 3,630 training and 840 test images, plus one pixel mask for each test image. Source images are not redistributed.

Class IDs: 1 = inclusions, 2 = patches, 3 = scratches.

Use `manifest.csv` and `dataset_summary.json` to verify file integrity and counts.
